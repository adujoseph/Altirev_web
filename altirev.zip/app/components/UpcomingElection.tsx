import React from 'react'

export default function UpcomingElection() {
  return (
    <div>
      <h2>All Upcoming Event</h2>
      <p>Upcoming Election Schedule: Know the Dates. Stay Engaged.</p>
      <div>
        
      </div>
    </div>
  );
}
