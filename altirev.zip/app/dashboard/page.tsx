import Dashboard from "../components/Dashboard";

export default function page() {
  return (
    <>
      <Dashboard />
    </>
  );
}
