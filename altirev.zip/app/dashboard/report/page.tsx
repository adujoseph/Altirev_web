
import Report from "@/app/components/Report";

export default function page() {
  
  return (
    <>
      <Report />
    </>
  );
}
