import Result from "@/app/components/Result";

export default function page() {

  return (
    <>
      <Result />
    </>
  );
}
